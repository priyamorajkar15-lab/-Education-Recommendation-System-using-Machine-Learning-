from flask import Flask, render_template, request, jsonify
import openai
import pickle
import numpy as np

app = Flask(__name__)

# Set up OpenAI API key
openai.api_key = "your-api-key-here"  # Replace with your actual API key

# Load the scaler and model
scaler = pickle.load(open("Models/scaler.pkl", 'rb'))
model = pickle.load(open("Models/model.pkl", 'rb'))

class_names = ['Lawyer', 'Doctor', 'Government Officer', 'Artist', 'Unknown',
               'Software Engineer', 'Teacher', 'Business Owner', 'Scientist',
               'Banker', 'Writer', 'Accountant', 'Designer',
               'Construction Engineer', 'Game Developer', 'Stock Investor',
               'Real Estate Developer']

@app.route('/chatbot', methods=['POST'])
def chatbot():
    """Chatbot API endpoint to handle user queries using OpenAI GPT"""
    user_input = request.json.get("message", "")

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",  # Use "gpt-4" if available
            messages=[{"role": "user", "content": user_input}]
        )
        bot_reply = response["choices"][0]["message"]["content"]
    except Exception as e:
        bot_reply = "Sorry, I'm having trouble responding right now."

    return jsonify({"response": bot_reply})

# Career Recommendations
@app.route('/pred', methods=['POST','GET'])
def pred():
    if request.method == 'POST':
        gender = request.form['gender']
        part_time_job = request.form['part_time_job'] == 'true'
        absence_days = int(request.form['absence_days'])
        extracurricular_activities = request.form['extracurricular_activities'] == 'true'
        weekly_self_study_hours = int(request.form['weekly_self_study_hours'])
        math_score = int(request.form['math_score'])
        history_score = int(request.form['history_score'])
        physics_score = int(request.form['physics_score'])
        chemistry_score = int(request.form['chemistry_score'])
        biology_score = int(request.form['biology_score'])
        english_score = int(request.form['english_score'])
        geography_score = int(request.form['geography_score'])
        total_score = float(request.form['total_score'])
        average_score = float(request.form['average_score'])

        gender_encoded = 1 if gender.lower() == 'female' else 0
        part_time_job_encoded = 1 if part_time_job else 0
        extracurricular_activities_encoded = 1 if extracurricular_activities else 0

        feature_array = np.array([[gender_encoded, part_time_job_encoded, absence_days, extracurricular_activities_encoded,
                                   weekly_self_study_hours, math_score, history_score, physics_score,
                                   chemistry_score, biology_score, english_score, geography_score, total_score,
                                   average_score]])

        scaled_features = scaler.transform(feature_array)
        probabilities = model.predict_proba(scaled_features)

        top_classes_idx = np.argsort(-probabilities[0])[:3]
        recommendations = [(class_names[idx], probabilities[0][idx]) for idx in top_classes_idx]

        return render_template('results.html', recommendations=recommendations)
    
    return render_template('home.html')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/recommend')
def recommend():
    return render_template('recommend.html')

@app.route('/chat')
def chat():
    return render_template('chatbot.html')

if __name__ == '__main__':
    app.run(debug=True)
